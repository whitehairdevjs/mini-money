package com.financialledge.config;

// CORS 설정은 SecurityConfig에서 처리합니다.
// 이 파일은 더 이상 사용되지 않지만 참조를 위해 남겨둡니다.

