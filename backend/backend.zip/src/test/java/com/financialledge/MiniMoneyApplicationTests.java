package com.financialledge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniMoneyApplicationTests {

    @Test
    void contextLoads() {
    }

}

